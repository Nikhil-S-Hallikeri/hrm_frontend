import React, { useState } from 'react'

const JoingingFormalities = () => {
    let [formObj, setFormObj] = useState({
        full_name: null,
        date_of_birth: null,
        gender: null,
        weight: null,
        height: null,
        present_address: null,
        Temprory_City: null,
        Temprory_State: null,
        Temprory_Pin: null,
        Temprory_Tel_No: null,
        mobile: null,
        email: null,
        permanent_address: null,
        Permanent_City: null,
        Permanent_State: null,
        Permanent_Pin: null,
        Permanent_Tel_No: null,
        Permanent_Mobile_NO: null
    })
    const handleFormObj = (e) => {
        let { name, value } = e.target
        setFormObj((prev) => ({
            ...prev,
            [name]: value
        }))
    }
    return (
        <div>
            <div className={`p-3 `}>
                <form>
                    {/* Form start */}
                    <div className="row justify-content-center m-0 ">
                        <h5 className='mt-2 heading' style={{ color: 'rgb(76,53,117)' }}>EMPLOYEE INFORMATION</h5>
                        <div className="col-lg-12 p-4 mt-2 border formbg rounded-lg ">
                            <div className="row m-0 pb-2">
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="Name" className="form-label">Full Name </label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" id="Name" name="full_name" value={formObj.full_name} onChange={(e) => handleFormObj(e)} />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="Name" className="form-label">Date Of Birth </label>
                                    <input type="date" className="p-2 block rounded bgclr w-full outline-none shadow-none" id="Name" name="date_of_birth" value={formObj.date_of_birth} onChange={(e) => handleFormObj(e)} />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="Name" className="form-label">Gender </label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" id="Name" name="gender" value={formObj.gender} onChange={(e) => handleFormObj(e)} />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="lastName" className="form-label">Weight</label>
                                    <input type="number" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.weight} onChange={(e) => handleFormObj(e)} id="LastName" name="weight" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="email" className="form-label">Height</label>
                                    <input type="number" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.height} onChange={(e) => handleFormObj(e)} id="Email" name="height" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="primaryContact" className="form-label" style={{ color: 'rgb(76,53,117)' }}>Temprory Address line 1</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.present_address} onChange={(e) => handleFormObj(e)} id="PrimaryContact" name="present_address" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">City</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Temprory_City} onChange={(e) => handleFormObj(e)} id="SecondaryContact" name="Temprory_City" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">State</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Temprory_State} onChange={(e) => handleFormObj(e)} id="State" name="Temprory_State" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Pin</label>
                                    <input type="number" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_Pin} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_Pin" />
                                </div>

                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Tel.No</label>
                                    <input type="tel" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Temprory_Tel_No} onChange={(e) => handleFormObj(e)} id="State" name="Temprory_Tel_No" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Mobile No</label>
                                    <input type="tel" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.mobile} onChange={(e) => handleFormObj(e)} id="State" name="mobile" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Email Id</label>
                                    <input type="email" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.email} onChange={(e) => handleFormObj(e)} id="State" name="email" />
                                </div>
                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label" style={{ color: 'rgb(76,53,117)' }}>Permanent Address line 1</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.permanent_address} onChange={(e) => handleFormObj(e)} id="State" name="permanent_address" />
                                </div>

                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">City</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_City} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_City" />
                                </div>

                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">State</label>
                                    <input type="text" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_State} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_State" />
                                </div>

                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Pin</label>
                                    <input type="number" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_Pin} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_Pin" />
                                </div>

                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Tel.No</label>
                                    <input type="tel" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_Tel_No} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_Tel_No" />
                                </div>


                                <div className="col-md-6 col-lg-4 mb-3">
                                    <label htmlFor="secondaryContact" className="form-label">Mobile No</label>
                                    <input type="tel" className="p-2 block rounded bgclr w-full outline-none shadow-none" value={formObj.Permanent_Mobile_NO} onChange={(e) => handleFormObj(e)} id="State" name="Permanent_Mobile_NO" />
                                </div>




                            </div>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    )
}

export default JoingingFormalities