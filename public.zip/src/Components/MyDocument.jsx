import React from 'react'
import { Document, Page, Text } from '@react-pdf/renderer';


const MyDocument = () => {
    return (
        <Document>
            <Page>
                <Text>Offer Letter</Text>
               <p>asdasdasdad</p>
            </Page>
        </Document>
    )
}

export default MyDocument


